package com.d3if0051.assessment1

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class DarkMode: Application() {

    override fun onCreate() {
        super.onCreate()
//        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
    }
}